from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


class Product(db.Model):
    __tablename__ = "products"

    id          = db.Column(db.Integer, primary_key=True)
    name        = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, default="")
    price       = db.Column(db.Float, nullable=False)
    stock       = db.Column(db.Integer, nullable=False, default=0)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

    cart_items  = db.relationship("CartItem",  back_populates="product", lazy="dynamic")
    order_items = db.relationship("OrderItem", back_populates="product", lazy="dynamic")

    def __repr__(self):
        return f"<Product {self.id}: {self.name} | stock={self.stock}>"

    def to_dict(self):
        return {
            "id":          self.id,
            "name":        self.name,
            "description": self.description,
            "price":       self.price,
            "stock":       self.stock,
        }


class Cart(db.Model):
    __tablename__ = "carts"

    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, nullable=False, unique=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    items = db.relationship("CartItem", back_populates="cart",
                            cascade="all, delete-orphan", lazy="dynamic")

    def __repr__(self):
        return f"<Cart {self.id} for user {self.user_id}>"

    def total(self):
        return sum(item.subtotal() for item in self.items)

    def to_dict(self):
        return {
            "cart_id": self.id,
            "user_id": self.user_id,
            "items":   [i.to_dict() for i in self.items],
            "total":   self.total(),
        }


class CartItem(db.Model):
    __tablename__ = "cart_items"
    __table_args__ = (
        db.UniqueConstraint("cart_id", "product_id", name="uq_cart_product"),
    )

    id         = db.Column(db.Integer, primary_key=True)
    cart_id    = db.Column(db.Integer, db.ForeignKey("carts.id"),    nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    quantity   = db.Column(db.Integer, nullable=False, default=1)

    cart    = db.relationship("Cart",    back_populates="items")
    product = db.relationship("Product", back_populates="cart_items")

    def subtotal(self):
        return self.product.price * self.quantity

    def to_dict(self):
        return {
            "cart_item_id": self.id,
            "product_id":   self.product_id,
            "product_name": self.product.name,
            "price":        self.product.price,
            "quantity":     self.quantity,
            "subtotal":     self.subtotal(),
        }


class Order(db.Model):
    __tablename__ = "orders"

    STATUS_PENDING   = "pending"
    STATUS_CONFIRMED = "confirmed"
    STATUS_CANCELLED = "cancelled"

    id          = db.Column(db.Integer, primary_key=True)
    user_id     = db.Column(db.Integer, nullable=False, index=True)
    status      = db.Column(db.String(20), nullable=False, default=STATUS_PENDING)
    total_price = db.Column(db.Float,   nullable=False, default=0.0)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

    items = db.relationship("OrderItem", back_populates="order",
                            cascade="all, delete-orphan", lazy="dynamic")

    def __repr__(self):
        return f"<Order {self.id} | user={self.user_id} | {self.status}>"

    def to_dict(self):
        return {
            "order_id":    self.id,
            "user_id":     self.user_id,
            "status":      self.status,
            "total_price": self.total_price,
            "created_at":  self.created_at.isoformat(),
            "items":       [i.to_dict() for i in self.items],
        }


class OrderItem(db.Model):
    __tablename__ = "order_items"

    id                = db.Column(db.Integer, primary_key=True)
    order_id          = db.Column(db.Integer, db.ForeignKey("orders.id"),   nullable=False)
    product_id        = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    quantity          = db.Column(db.Integer, nullable=False)
    price_at_purchase = db.Column(db.Float,  nullable=False)

    order   = db.relationship("Order",   back_populates="items")
    product = db.relationship("Product", back_populates="order_items")

    def subtotal(self):
        return self.price_at_purchase * self.quantity

    def to_dict(self):
        return {
            "order_item_id":     self.id,
            "product_id":        self.product_id,
            "product_name":      self.product.name,
            "quantity":          self.quantity,
            "price_at_purchase": self.price_at_purchase,
            "subtotal":          self.subtotal(),
        }
