import pytest
from app import create_app
from config import TestConfig
from models import db as _db, Product, Cart, CartItem, Order, OrderItem


@pytest.fixture(scope="function")
def app():
    application = create_app(TestConfig)
    with application.app_context():
        _db.create_all()
        yield application
        _db.session.remove()
        _db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def sample_products(app):
    with app.app_context():
        p1 = Product(name="Widget A", price=10.0,  stock=5)
        p2 = Product(name="Widget B", price=25.50, stock=3)
        _db.session.add_all([p1, p2])
        _db.session.commit()
        return p1.id, p2.id


def add_item(client, user_id, product_id, quantity):
    return client.post(
        f"/cart/{user_id}/add",
        json={"product_id": product_id, "quantity": quantity},
        content_type="application/json",
    )


def checkout(client, user_id):
    return client.post(f"/orders/checkout/{user_id}")


def get_stock(app, product_id):
    with app.app_context():
        return Product.query.get(product_id).stock


class TestProductStock:

    def test_create_product(self, client):
        r = client.post("/products/", json={"name": "Gadget", "price": 9.99, "stock": 10})
        assert r.status_code == 201
        data = r.get_json()
        assert data["name"]  == "Gadget"
        assert data["stock"] == 10

    def test_create_product_missing_fields(self, client):
        r = client.post("/products/", json={"name": "No Price"})
        assert r.status_code == 400

    def test_create_product_negative_price(self, client):
        r = client.post("/products/", json={"name": "Bad", "price": -1})
        assert r.status_code == 400

    def test_list_products(self, client, sample_products):
        r = client.get("/products/")
        assert r.status_code == 200
        assert len(r.get_json()) == 2

    def test_update_stock(self, client, sample_products):
        pid, _ = sample_products
        r = client.put(f"/products/{pid}", json={"stock": 20})
        assert r.status_code == 200
        assert r.get_json()["stock"] == 20


class TestCartOperations:

    def test_view_empty_cart(self, client):
        r = client.get("/cart/99")
        assert r.status_code == 200
        data = r.get_json()
        assert data["items"] == []
        assert data["total"] == 0.0

    def test_add_item_to_cart(self, client, sample_products):
        pid, _ = sample_products
        r = add_item(client, user_id=1, product_id=pid, quantity=2)
        assert r.status_code == 200
        data = r.get_json()
        assert len(data["items"]) == 1
        assert data["items"][0]["quantity"] == 2
        assert data["total"] == pytest.approx(20.0)

    def test_add_same_item_twice_accumulates(self, client, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 1)
        r = add_item(client, 1, pid, 2)
        assert r.status_code == 200
        assert r.get_json()["items"][0]["quantity"] == 3

    def test_add_multiple_products(self, client, sample_products):
        pid1, pid2 = sample_products
        add_item(client, 1, pid1, 1)
        r = add_item(client, 1, pid2, 1)
        assert r.status_code == 200
        assert len(r.get_json()["items"]) == 2

    def test_remove_item_from_cart(self, client, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 1)
        r = client.delete(f"/cart/1/remove/{pid}")
        assert r.status_code == 200
        assert r.get_json()["items"] == []

    def test_update_cart_item_quantity(self, client, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 1)
        r = client.put(f"/cart/1/update/{pid}", json={"quantity": 3})
        assert r.status_code == 200
        assert r.get_json()["items"][0]["quantity"] == 3

    def test_update_to_zero_removes_item(self, client, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 1)
        r = client.put(f"/cart/1/update/{pid}", json={"quantity": 0})
        assert r.status_code == 200
        assert r.get_json()["items"] == []

    def test_clear_cart(self, client, sample_products):
        pid1, pid2 = sample_products
        add_item(client, 1, pid1, 1)
        add_item(client, 1, pid2, 1)
        r = client.delete("/cart/1/clear")
        assert r.status_code == 200
        assert client.get("/cart/1").get_json()["items"] == []

    def test_add_nonexistent_product(self, client):
        r = add_item(client, user_id=1, product_id=9999, quantity=1)
        assert r.status_code == 404

    def test_add_zero_quantity_rejected(self, client, sample_products):
        pid, _ = sample_products
        r = add_item(client, 1, pid, 0)
        assert r.status_code == 400

    def test_add_negative_quantity_rejected(self, client, sample_products):
        pid, _ = sample_products
        r = add_item(client, 1, pid, -1)
        assert r.status_code == 400


class TestStockValidation:

    def test_add_exceeds_stock_rejected(self, client, sample_products):
        pid, _ = sample_products
        r = add_item(client, 1, pid, 6)
        assert r.status_code == 409
        body = r.get_json()
        assert body["requested"] == 6
        assert body["available"] == 5

    def test_cumulative_add_exceeds_stock(self, client, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 3)
        r = add_item(client, 1, pid, 3)
        assert r.status_code == 409
        assert r.get_json()["requested"] == 6

    def test_update_exceeds_stock_rejected(self, client, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 1)
        r = client.put(f"/cart/1/update/{pid}", json={"quantity": 10})
        assert r.status_code == 409

    def test_exactly_at_stock_limit_allowed(self, client, sample_products):
        pid, _ = sample_products
        r = add_item(client, 1, pid, 5)
        assert r.status_code == 200

    def test_add_one_more_than_stock_rejected(self, client, sample_products):
        pid, _ = sample_products
        r = add_item(client, 1, pid, 6)
        assert r.status_code == 409


class TestCheckout:

    def test_checkout_creates_order(self, client, sample_products):
        pid1, pid2 = sample_products
        add_item(client, 1, pid1, 2)
        add_item(client, 1, pid2, 1)
        r = checkout(client, 1)
        assert r.status_code == 201
        order = r.get_json()
        assert order["status"] == "confirmed"
        assert len(order["items"]) == 2

    def test_checkout_calculates_total(self, client, sample_products):
        pid1, pid2 = sample_products
        add_item(client, 1, pid1, 2)
        add_item(client, 1, pid2, 1)
        r = checkout(client, 1)
        assert r.get_json()["total_price"] == pytest.approx(45.50)

    def test_checkout_deducts_stock(self, client, app, sample_products):
        pid1, _ = sample_products
        add_item(client, 1, pid1, 3)
        checkout(client, 1)
        assert get_stock(app, pid1) == 2

    def test_checkout_clears_cart(self, client, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 1)
        checkout(client, 1)
        cart = client.get("/cart/1").get_json()
        assert cart["items"] == []

    def test_checkout_empty_cart_rejected(self, client):
        r = checkout(client, 42)
        assert r.status_code == 400
        assert "empty" in r.get_json()["error"].lower()

    def test_checkout_snapshot_price(self, client, app, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 1)
        client.put(f"/products/{pid}", json={"price": 99.99})
        r = checkout(client, 1)
        order = r.get_json()
        assert order["items"][0]["price_at_purchase"] == pytest.approx(99.99)
        assert order["total_price"] == pytest.approx(99.99)

    def test_checkout_stock_validation_at_checkout_time(self, client, app, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 5)
        with app.app_context():
            p = Product.query.get(pid)
            p.stock = 2
            _db.session.commit()
        r = checkout(client, 1)
        assert r.status_code == 409
        body = r.get_json()
        assert body["details"][0]["available"] == 2

    def test_multiple_users_independent_carts(self, client, sample_products):
        pid, _ = sample_products
        add_item(client, user_id=1, product_id=pid, quantity=2)
        add_item(client, user_id=2, product_id=pid, quantity=2)
        r1 = checkout(client, 1)
        r2 = checkout(client, 2)
        assert r1.status_code == 201
        assert r2.status_code == 201

    def test_second_checkout_fails_when_stock_exhausted(self, client, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 5)
        checkout(client, 1)
        r = add_item(client, 2, pid, 1)
        assert r.status_code == 409


class TestOrderManagement:

    def test_list_user_orders(self, client, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 1)
        checkout(client, 1)
        r = client.get("/orders/user/1")
        assert r.status_code == 200
        assert len(r.get_json()) == 1

    def test_get_order_detail(self, client, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 1)
        order_id = checkout(client, 1).get_json()["order_id"]
        r = client.get(f"/orders/{order_id}")
        assert r.status_code == 200
        assert r.get_json()["order_id"] == order_id

    def test_cancel_order_restores_stock(self, client, app, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 3)
        order_id = checkout(client, 1).get_json()["order_id"]
        assert get_stock(app, pid) == 2
        r = client.post(f"/orders/{order_id}/cancel")
        assert r.status_code == 200
        assert r.get_json()["status"] == "cancelled"
        assert get_stock(app, pid) == 5

    def test_cancel_already_cancelled_order(self, client, sample_products):
        pid, _ = sample_products
        add_item(client, 1, pid, 1)
        order_id = checkout(client, 1).get_json()["order_id"]
        client.post(f"/orders/{order_id}/cancel")
        r = client.post(f"/orders/{order_id}/cancel")
        assert r.status_code == 400

    def test_get_nonexistent_order(self, client):
        r = client.get("/orders/9999")
        assert r.status_code == 404
