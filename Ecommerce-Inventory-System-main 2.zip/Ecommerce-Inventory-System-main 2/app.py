from flask import Flask, jsonify
from config import Config
from models import db
from routes.products import products_bp
from routes.cart import cart_bp
from routes.orders import orders_bp


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)

    app.register_blueprint(products_bp)
    app.register_blueprint(cart_bp)
    app.register_blueprint(orders_bp)

    @app.route("/")
    def home():
        return jsonify({
            "message": "Welcome to E-Commerce and Inventory Management System!",
            "endpoints": {
                "products": "/products/",
                "cart":     "/cart/<user_id>",
                "orders":   "/orders/checkout/<user_id>",
            }
        })

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": "Resource not found"}), 404

    @app.errorhandler(405)
    def method_not_allowed(e):
        return jsonify({"error": "Method not allowed"}), 405

    return app


if __name__ == "__main__":
    app = create_app()
    with app.app_context():
        db.create_all()
    app.run(debug=True)
