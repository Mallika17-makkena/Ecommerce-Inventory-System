from flask import Blueprint, request, jsonify
from models import db, Cart, CartItem, Product

cart_bp = Blueprint("cart", __name__, url_prefix="/cart")


def _get_or_create_cart(user_id: int) -> Cart:
    cart = Cart.query.filter_by(user_id=user_id).first()
    if not cart:
        cart = Cart(user_id=user_id)
        db.session.add(cart)
        db.session.flush()
    return cart


@cart_bp.route("/<int:user_id>", methods=["GET"])
def view_cart(user_id):
    cart = Cart.query.filter_by(user_id=user_id).first()
    if not cart:
        return jsonify({"cart_id": None, "user_id": user_id, "items": [], "total": 0.0}), 200
    return jsonify(cart.to_dict()), 200


@cart_bp.route("/<int:user_id>/add", methods=["POST"])
def add_to_cart(user_id):
    data       = request.get_json(silent=True) or {}
    product_id = data.get("product_id")
    quantity   = data.get("quantity", 1)

    if product_id is None:
        return jsonify({"error": "product_id is required"}), 400
    if not isinstance(quantity, int) or quantity < 1:
        return jsonify({"error": "quantity must be an integer >= 1"}), 400

    product = Product.query.get(product_id)
    if not product:
        return jsonify({"error": f"Product {product_id} not found"}), 404

    cart      = _get_or_create_cart(user_id)
    cart_item = CartItem.query.filter_by(cart_id=cart.id, product_id=product_id).first()
    existing  = cart_item.quantity if cart_item else 0
    requested = existing + quantity

    if requested > product.stock:
        return jsonify({
            "error":     "Insufficient stock",
            "requested": requested,
            "available": product.stock,
        }), 409

    if cart_item:
        cart_item.quantity = requested
    else:
        cart_item = CartItem(cart_id=cart.id, product_id=product_id, quantity=quantity)
        db.session.add(cart_item)

    db.session.commit()
    return jsonify(cart.to_dict()), 200


@cart_bp.route("/<int:user_id>/update/<int:product_id>", methods=["PUT"])
def update_cart_item(user_id, product_id):
    data     = request.get_json(silent=True) or {}
    quantity = data.get("quantity")

    if quantity is None or not isinstance(quantity, int) or quantity < 0:
        return jsonify({"error": "quantity must be an integer >= 0"}), 400

    cart = Cart.query.filter_by(user_id=user_id).first()
    if not cart:
        return jsonify({"error": "Cart not found"}), 404

    cart_item = CartItem.query.filter_by(cart_id=cart.id, product_id=product_id).first()
    if not cart_item:
        return jsonify({"error": "Item not in cart"}), 404

    if quantity == 0:
        db.session.delete(cart_item)
        db.session.commit()
        return jsonify({"message": "Item removed", **cart.to_dict()}), 200

    product = Product.query.get(product_id)
    if quantity > product.stock:
        return jsonify({
            "error":     "Insufficient stock",
            "requested": quantity,
            "available": product.stock,
        }), 409

    cart_item.quantity = quantity
    db.session.commit()
    return jsonify(cart.to_dict()), 200


@cart_bp.route("/<int:user_id>/remove/<int:product_id>", methods=["DELETE"])
def remove_from_cart(user_id, product_id):
    cart = Cart.query.filter_by(user_id=user_id).first()
    if not cart:
        return jsonify({"error": "Cart not found"}), 404

    cart_item = CartItem.query.filter_by(cart_id=cart.id, product_id=product_id).first()
    if not cart_item:
        return jsonify({"error": "Item not in cart"}), 404

    db.session.delete(cart_item)
    db.session.commit()
    return jsonify({"message": "Item removed", **cart.to_dict()}), 200


@cart_bp.route("/<int:user_id>/clear", methods=["DELETE"])
def clear_cart(user_id):
    cart = Cart.query.filter_by(user_id=user_id).first()
    if not cart:
        return jsonify({"message": "Cart already empty"}), 200

    for item in cart.items:
        db.session.delete(item)
    db.session.commit()
    return jsonify({"message": "Cart cleared"}), 200
