from flask import Blueprint, request, jsonify
from models import db, Cart, Order, OrderItem, Product

orders_bp = Blueprint("orders", __name__, url_prefix="/orders")


@orders_bp.route("/checkout/<int:user_id>", methods=["POST"])
def checkout(user_id):
    cart = Cart.query.filter_by(user_id=user_id).first()

    if not cart or cart.items.count() == 0:
        return jsonify({"error": "Cart is empty – nothing to checkout"}), 400

    items = list(cart.items)

    insufficient = []
    for ci in items:
        product = Product.query.get(ci.product_id)
        if not product:
            insufficient.append({
                "product_id": ci.product_id,
                "issue":      "Product no longer exists",
            })
        elif ci.quantity > product.stock:
            insufficient.append({
                "product_id":   ci.product_id,
                "product_name": product.name,
                "requested":    ci.quantity,
                "available":    product.stock,
            })

    if insufficient:
        return jsonify({
            "error":   "Stock validation failed for one or more items",
            "details": insufficient,
        }), 409

    total = 0.0
    order = Order(user_id=user_id, status=Order.STATUS_CONFIRMED)
    db.session.add(order)
    db.session.flush()

    for ci in items:
        product        = Product.query.get(ci.product_id)
        product.stock -= ci.quantity
        line_total     = product.price * ci.quantity
        total         += line_total

        order_item = OrderItem(
            order_id          = order.id,
            product_id        = ci.product_id,
            quantity          = ci.quantity,
            price_at_purchase = product.price,
        )
        db.session.add(order_item)

    order.total_price = total

    for ci in items:
        db.session.delete(ci)

    db.session.commit()
    return jsonify(order.to_dict()), 201


@orders_bp.route("/user/<int:user_id>", methods=["GET"])
def list_orders(user_id):
    orders = Order.query.filter_by(user_id=user_id).all()
    return jsonify([o.to_dict() for o in orders]), 200


@orders_bp.route("/<int:order_id>", methods=["GET"])
def get_order(order_id):
    order = Order.query.get_or_404(order_id)
    return jsonify(order.to_dict()), 200


@orders_bp.route("/<int:order_id>/cancel", methods=["POST"])
def cancel_order(order_id):
    order = Order.query.get_or_404(order_id)

    if order.status == Order.STATUS_CANCELLED:
        return jsonify({"error": "Order is already cancelled"}), 400

    for oi in order.items:
        product = Product.query.get(oi.product_id)
        if product:
            product.stock += oi.quantity

    order.status = Order.STATUS_CANCELLED
    db.session.commit()
    return jsonify(order.to_dict()), 200
