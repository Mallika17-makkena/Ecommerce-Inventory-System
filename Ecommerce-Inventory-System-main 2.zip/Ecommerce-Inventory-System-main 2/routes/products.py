from flask import Blueprint, request, jsonify
from models import db, Product

products_bp = Blueprint("products", __name__, url_prefix="/products")


@products_bp.route("/", methods=["GET"])
def list_products():
    products = Product.query.all()
    return jsonify([p.to_dict() for p in products]), 200


@products_bp.route("/<int:product_id>", methods=["GET"])
def get_product(product_id):
    product = Product.query.get_or_404(product_id)
    return jsonify(product.to_dict()), 200


@products_bp.route("/", methods=["POST"])
def create_product():
    data  = request.get_json(silent=True) or {}
    name  = data.get("name")
    price = data.get("price")
    stock = data.get("stock", 0)

    if not name or price is None:
        return jsonify({"error": "name and price are required"}), 400
    if price < 0:
        return jsonify({"error": "price must be non-negative"}), 400
    if stock < 0:
        return jsonify({"error": "stock must be non-negative"}), 400

    product = Product(
        name=name,
        description=data.get("description", ""),
        price=float(price),
        stock=int(stock),
    )
    db.session.add(product)
    db.session.commit()
    return jsonify(product.to_dict()), 201


@products_bp.route("/<int:product_id>", methods=["PUT"])
def update_product(product_id):
    product = Product.query.get_or_404(product_id)
    data = request.get_json(silent=True) or {}

    if "name" in data:
        product.name = data["name"]
    if "price" in data:
        if data["price"] < 0:
            return jsonify({"error": "price must be non-negative"}), 400
        product.price = float(data["price"])
    if "stock" in data:
        if data["stock"] < 0:
            return jsonify({"error": "stock must be non-negative"}), 400
        product.stock = int(data["stock"])
    if "description" in data:
        product.description = data["description"]

    db.session.commit()
    return jsonify(product.to_dict()), 200


@products_bp.route("/<int:product_id>", methods=["DELETE"])
def delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    return jsonify({"message": f"Product {product_id} deleted"}), 200
